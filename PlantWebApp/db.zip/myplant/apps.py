from django.apps import AppConfig


class MyplantConfig(AppConfig):

    name = 'myplant'
